function clearErrors(){

     var errors = document.getElementsByClassName('formerror');
    for(let item of errors)
    {
        item.innerHTML = "";
    }


}
function seterror(id, error){
    //sets error inside tag of id 
    element = document.getElementById(id);
    element.getElementsByClassName('formerror')[0].innerHTML = error;

}

function validateForm(){
    var returnval = true;
    clearErrors();


    //perform validation and if validation fails, set the value of returnval to false
    var name = document.forms['myForm']["fname"].value;
    if (name.length<5){
        seterror("name", "*Length of name is too short");
        returnval = false;
        console.log("enter your name",name);
        
    }

    if (name.length == 0){
        seterror("name", "*Please enter the name");
        returnval = false;
    }

    var email = document.forms['myForm']["femail"].value;
    if (email.length>15){
        seterror("email", "*Email length is too long");
        returnval = false;
        console.log("enter your email",email);
    }

    var phone = document.forms['myForm']["fphone"].value;
    if (phone.length != 10){
        seterror("phone", "*Phone number should be of 10 digits!");
        returnval = false;
        console.log("enter your phone",phone);
    }

    var password = document.forms['myForm']["fpass"].value;
    var matchpassword = /^[A-Za-z]\w{7,14}$/;

        if(password.match(matchpassword)){
        seterror("pass", "correct");
        returnval = false;
        }else{
        seterror("pass", "password should contain capital letter , small letter ,number ");
        returnval = false;
        console.log("enter your password",password);

        }

    var cpassword = document.forms['myForm']["fcpass"].value;
    if (cpassword != password){
        seterror("cpass", "*Password and Confirm password should match!");
        returnval = false;
        console.log("re-enter the paassword",cpassword);
    }
   if(returnval){
    showToast();
  
   }
    return returnval;
}
//toggle password
const togglePassword = document.querySelector("#togglePassword");
const password= document.querySelector("#password");

togglePassword.addEventListener("click", function(){
    const type = password.getAttribute("type")==="password"?"text":"password";
    password.setAttribute("type",type);

    this.classList.toggle('fa-eye-slash');
    this.classList.toggle('fa-eye');

})


//toster popup
document.addEventListener("DOMContentLoaded",function(){
    const toast = document.getElementById("toast");
    const showtoaster = document.getElementById("but");

    showtoaster.addEventListener("click",function(){
        showToast();
    });

    function showToast(){
        toast.style.display = "block";
        setTimeout(function (){
            toast.style.display = "none";
        },5000);
    }
});

//Edit button 




